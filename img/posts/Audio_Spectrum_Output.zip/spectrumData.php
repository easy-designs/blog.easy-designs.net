<?php
	$spectrumData = $_POST['json'];
	$myFile = "spectrumData/spectrumData.txt";
	$fh = fopen($myFile, 'w') or die("can't open file");
	fwrite($fh, stripSlashes($spectrumData));
	fclose($fh);
	echo 'Spectrum Data Saved as json object in spectrumData.txt';
?>